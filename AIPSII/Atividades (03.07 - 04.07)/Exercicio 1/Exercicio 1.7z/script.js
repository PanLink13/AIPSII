function numeroAleatorio(){
    let aleatorio
    aleatorio = Math.floor(Math.random() * 2)
    alert(aleatorio)
}